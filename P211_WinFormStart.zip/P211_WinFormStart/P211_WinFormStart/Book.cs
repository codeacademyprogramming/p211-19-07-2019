﻿namespace P211_WinFormStart
{
    public class Book
    {
        private static int _counter = 1;
        public string Id { get; private set; }
        public string Name { get; set; }
        public string GenreId { get; set; }

        public Book()
        {
            Id = new string('0', 6 - _counter.ToString().Length) + _counter;
            _counter++;
        }
    }
}
