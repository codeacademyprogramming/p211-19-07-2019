﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P211_WinFormStart
{
    public static class BookList
    {
        private static List<Book> books = new List<Book>
        {
            new Book { Name = "Book 1", GenreId = GenreList.GetGenreIdByName("Crime")},
            new Book { Name = "Book 2", GenreId = GenreList.GetGenreIdByName("Love")},
            new Book { Name = "Book 3", GenreId = GenreList.GetGenreIdByName("Crime")},
            new Book { Name = "Book 4", GenreId = GenreList.GetGenreIdByName("Sebuhi")},
            new Book { Name = "Book 5", GenreId = GenreList.GetGenreIdByName("Crime")},
            new Book { Name = "Book 6", GenreId = GenreList.GetGenreIdByName("Love")}
        };

        public static List<Book> GetBooks() => books;

        public static void AddBook(Book book)
        {
            books.Add(book);
        }

        public static IEnumerable<Book> GetBooksByGenreId(string genreId)
        {
            List<Book> resultlist = new List<Book>();

            foreach (var book in books)
            {
                if(book.GenreId == genreId)
                {
                    resultlist.Add(book);
                }
            }

            return resultlist;
        }
    }
}
