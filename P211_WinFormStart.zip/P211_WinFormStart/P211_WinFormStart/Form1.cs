﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P211_WinFormStart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
            #region Update Welcome label on typing username

            //hide lblError label
            lblError.Visible = false;

            string username = txtUsername.Text;

            if (username.Trim() == string.Empty)
            {
                lblWelcome.Text = $"Welcome, honey";
            }
            else
            {
                lblWelcome.Text = $"Welcome, {username}";
            }
            #endregion
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim().ToLower();
            string password = txtPassword.Text.Trim();

            if(username == "admin" && password == "Admin123")
            {
                AdminForm adminForm = new AdminForm();
                adminForm.ShowDialog();
            }
            else
            {
                //MessageBox.Show("You just failed, babuska!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblError.Text = "Username or password is invalid";
                lblError.Visible = true;
            }
        }
    }
}
