﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P211_WinFormStart
{
    public  class Product
    {
        private static int _counter = 1000;
        public string Id { get; private set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string CategoryId { get; set; }

        public Product()
        {
            Id = new string('0', 10 - _counter.ToString().Length) + _counter.ToString();
            _counter++;
        }

    }
}
