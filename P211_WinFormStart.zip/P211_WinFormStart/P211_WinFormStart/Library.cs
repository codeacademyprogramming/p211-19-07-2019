﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P211_WinFormStart
{
    public partial class Library : Form
    {
        public Library()
        {
            InitializeComponent();
            string books = "";
            foreach (var item in BookList.GetBooks())
            {
                books += item.Name;
            }
        }

        private void Library_Load(object sender, EventArgs e)
        {
            foreach (Genre genre in GenreList.GetGenres())
            {
                cmbGenres.Items.Add(genre.Name);
            }
        }

        private void BtnCreateBook_Click(object sender, EventArgs e)
        {
            string bookName = txtBookname.Text.Trim();
            string genreName = cmbGenres.Text.Trim();

            if(bookName == "")
            {
                MessageBox.Show("Book name is empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if(genreName == "")
            {
                MessageBox.Show("Genre should be selected","Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string selectedGenreId = GenreList.GetGenreIdByName(genreName);

            Book newBook = new Book { Name = bookName, GenreId = selectedGenreId };
            BookList.AddBook(newBook);

            lbBooks.Items.Clear();
            //load all books names to ListBox
            foreach (Book book in BookList.GetBooks())
            {
                lbBooks.Items.Add($"{book.Id} - {book.Name}");
            }

        }

        private void BtnSearchBook_Click(object sender, EventArgs e)
        {
            string genreName = txtSearchBook.Text.Trim();

            string genreId = GenreList.GetGenreIdByName(genreName);

            if(genreId == null)
            {
                MessageBox.Show("This genre doesn't exist in our database", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            List<Book> books = BookList.GetBooksByGenreId(genreId).ToList();

            lbBooks.Items.Clear();
            foreach (var item in books)
            {
                lbBooks.Items.Add($"{item.Id} {item.Name}");
            }

        }
    }
}
