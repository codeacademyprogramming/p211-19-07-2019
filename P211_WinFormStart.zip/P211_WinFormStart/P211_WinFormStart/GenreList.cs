﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P211_WinFormStart
{
    public static class GenreList
    {
        private static HashSet<Genre> genres = new HashSet<Genre>
        {
            //seed
            new Genre{ Name = "Love" },
            new Genre{ Name = "Crime" },
            new Genre{ Name = "Sebuhi" }
        };

        //CRUD - Create, Read, Update, Delete

        public static IEnumerable<Genre> GetGenres()
        {
            return genres;
        }

        public static void AddGenre(Genre g)
        {
            genres.Add(g);
        }

        public static string GetGenreIdByName(string genreName)
        {
            foreach (Genre genre in genres)
            {
                if(genre.Name.ToLower() == genreName.ToLower())
                {
                    return genre.Id;
                }
            }

            return null;
        }

    }
}
